<template>
  <div id="app">
    <Header />
    <!-- 书写路由组件 -->
    <router-view></router-view>
    <!-- 在Home、Search显示，在登录、注册隐藏 -->
    <Footer v-show="$route.meta.show" />
  </div>
</template>

<script>
import Header from "./components/Header/index.vue";
import Footer from "./components/Footer/index.vue";

export default {
  name: "App",
  components: {
    Header,
    Footer,
  },
  mounted() {
    // 派发一个action，获取商品分类的三级列表的数组
    this.$store.dispatch("categoryList");
  },
};
</script>

<style></style>
