<template>
  <!-- 轮播图 -->
  <div class="swiper-container" ref="cur">
    <div class="swiper-wrapper">
      <div class="swiper-slide" v-for="carousel in list" :key="carousel.id">
        <img :src="carousel.imgUrl" />
      </div>
    </div>
    <!-- 如果需要分页器 -->
    <div class="swiper-pagination"></div>

    <!-- 如果需要导航按钮 -->
    <div class="swiper-button-prev"></div>
    <div class="swiper-button-next"></div>
  </div>
</template>

<script>
// 引入Swiper
import Swiper from "swiper";
export default {
  name: "Carousel",
  props: ["list"],
  watch: {
    list: {
      // 立即监听：不管数据有没有变化，一上来就立即监听一次
      immediate: true,
      // watch监听不到list的变化是因为这个数据没有发生变化（数据是父组件传过来的，里面本身是个对象，不需要改变）
      handler(newValue, oldValue) {
        // 只能监听到数据已经有了，但是v-for动态渲染的结构我们还是没有办法确定，因此还是需要用nextTick
        this.$nextTick(() => {
          new Swiper(this.$refs.cur, {
            loop: true, // 循环模式选项
            autoplay: true, // 轮播自动
            // 如果需要分页器
            pagination: {
              el: ".swiper-pagination",
              clickable: true,
            },
            // 如果需要前进后退按钮
            navigation: {
              nextEl: ".swiper-button-next",
              prevEl: ".swiper-button-prev",
            },
          });
        });
      },
    },
  },
};
</script>

<style>
</style>